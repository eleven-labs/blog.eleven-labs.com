# Salade Tomate Oignon: the workflow files

The Claude Code configuration of a private game, shared alongside the article "The workflow is a
product" on the Eleven Labs blog. Fichiers de configuration Claude Code d'un jeu privé, partagés
avec l'article « Le workflow est un produit » du blog d'Eleven Labs.

- `CLAUDE.md`: the direction, the documents of record, the workflow.
- `.claude/settings.json`: the permissions allowlist and the hooks' wiring.
- `.claude/hooks/`: format and lint, refuse commits on main, refuse tests while bots run, say at
  session start what is already running.
- `.claude/rules/`: rules that load with the files they concern.
- `.claude/skills/`: next, milestone, ship, brief, bot.

`.claude/` is a hidden folder: show hidden files to see it.

To read and adapt, not to install as is. The game's code, `docs/` and `scripts/` are not included,
so what points at them won't run here. Private links and hosts are replaced by `<placeholders>`.

MIT licensed: see `LICENSE`.
