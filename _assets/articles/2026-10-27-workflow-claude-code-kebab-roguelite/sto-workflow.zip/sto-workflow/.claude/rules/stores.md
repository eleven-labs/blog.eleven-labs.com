---
paths:
  - 'src/stores/**'
---

# Stores

- Four Zustand stores, one file each: `run` (the run in progress), `meta` (recipe book, unlocks,
  stats), `ui` (current screen, animations) and `hallOfFame` (the outbox of the runs posted to the
  hall of fame's server). Each file exports fine-grained selectors.
- Only `hallOfFame` talks to the network (`hallOfFameApi.ts`): at the end of a run, on opening the
  app (the stats) and its own pages, never in play.
- A store holds state and calls the engine; it contains no game rule.
- `meta` is its own context: it reads a run only through an end-of-run summary.
- Persistence uses Zustand's `persist` on localStorage with a `version` and a `migrate` for the
  schema. The run is saved after every action; there is no undo.
