---
paths:
  - 'src/tests/**'
  - 'e2e/**'
  - 'vite.config.ts'
  - 'playwright.config.ts'
---

# Tests

- Specs live in `src/tests/`, mirroring `src/`, not next to the sources. Write them first and show
  the red run.
- Vitest runs with globals in three projects (`vite.config.ts`): `node` for `engine/` and
  `content/` specs, `dom` (jsdom, with `src/tests/setup.ts` for the jest-dom matchers) for the
  rest, and `server` for the hall of fame's server, whose specs live in `server/tests/`.
- A rule of the brief gets a test named after it ("règle 5 : une exigence violée refuse le
  kebab"); tables of values become `it.each`.
- Component specs use React Testing Library by role and accessible name, reading texts from
  `src/content/fr/`. Pages render through `createMemoryRouter(routes)`.
- Vitest tests the French only (decided 27 October 2026): no spec loops over the languages or
  checks the English or Italian words, which their types hold to the French. A text of any language
  too long for its box is caught by `pnpm e2e`; `pnpm screenshots --lang` is for the voice and the
  look.
- Vitest runs from the repo root only: the style and content specs read `src/…` and `index.html`
  by paths relative to it, and from `src/` Vitest finds no test at all ("no tests" reads as
  green). No `cd` in a command that runs it: a `cd` carries over to the next shell call.
- Run from Claude Code, Vitest hides console output and React warnings: pass `--silent=false`
  (`pnpm exec vitest run --silent=false <file>`) to see them.
- Specs that play bots (`scripts/greedy.ts`, `run.ts`, `smart.ts`) stay minimal: one or two
  runs, the essential property only (the run ends, a run can be won). Win rates are measured by
  `pnpm bot`, never in a spec: the CI and the machine must not be loaded.
- The coverage gate is 90 % on `src/engine/` and is never lowered. Look at coverage at the end of a
  task, not while working.
- Judge `pnpm check` by its exit code (`; echo rc=$?`) or its tail, never by a `grep` of its
  output: a filter once hid Prettier's `[warn]` lines and the missing build line.
- Vitest caches transformed modules in `node_modules/.vitest-cache`: a module whose source didn't
  change keeps its old `import.meta.glob` result, so a new file in `src/sprites/` reads as
  missing. `rm -rf node_modules/.vitest-cache` and rerun.
- No vitest run while bots run (a hook refuses it): specs that play whole runs time out.
- `pnpm e2e` is Playwright on the built site (`vite preview` on 5197, the system Chrome), apart
  from Vitest and its coverage: `e2e/overflow.e2e.ts` walks every screen of `scripts/screens.ts`
  (the screenshots' list, a new screen goes there) at 360 px and on desktop in each language, and
  fails on a text past its first box (border, background or clip), skipping out-of-sight text, an
  ellipsis and a scrolling box; `e2e/smoke.e2e.ts` plays a new run's first service and a market
  through reloads, the clock fixed so the seed is too; `e2e/receipt.e2e.ts` serves the longest
  ticket on desktop and on a phone in each language: nothing in it scrolls, the hand keeps its
  place on desktop and stays above the action bar on a phone; `e2e/stamp.e2e.ts` sets each
  verdict's stamp of every language on the served ticket, in full and reduced motion: nothing
  around it clips it and it stays off the total's figures. A
  screen's behaviour stays a Vitest spec: an e2e test is for what jsdom can't see (layout, the
  real save, reloads).
