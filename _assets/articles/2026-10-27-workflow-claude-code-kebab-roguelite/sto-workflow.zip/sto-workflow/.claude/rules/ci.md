---
paths:
  - '.github/**'
  - 'package.json'
---

# CI

- `check.yml` (Node from `.nvmrc`, pnpm from `packageManager`) runs `lint:check`, `type-check`,
  `test:coverage` and `build-only` on pull requests and pushes to `main`, one step each: every
  check runs even after one fails (`if: *after-install`), the build only once they all pass.
  `pnpm check` runs the same steps: when you add a check, add it to both. They stay steps of one
  job: the repo is private and each job is billed by the started minute.
- Dependabot (`.github/dependabot.yml`) opens weekly update PRs for the dependencies and the
  workflow's actions; they go through the same check.
- On pushes to `main` (and a manual run of `main`, which always deploys), the `check` job builds
  the site and the hall of fame's server, fingerprints `dist/` and `dist-server/` together into
  `build-hash.txt` and compares it with https://<game-site>/build-hash.txt; the `deploy` job ships
  only a different build: the server first (beside the live one in `server.next/`, migrated from
  there, then put in place and the service restarted), then the site, the
  fingerprint last, then checks it live (the public fingerprint) and locked (`/`, a bundle and
  `/api/me` redirect to the Google login at `<auth-host>`). The site and the server always go
  from the same commit: the server refuses a run of another version. Deploying is a second job,
  billed only when the build changed, so a failed upload re-runs without rebuilding; it refuses a run that is no longer main's tip, and
  keeps old hashed assets two weeks for tabs still open. The server side (vhost, certificate, Google login) is in a private skill. Redeploy:
  `gh workflow run Check --ref main`.
