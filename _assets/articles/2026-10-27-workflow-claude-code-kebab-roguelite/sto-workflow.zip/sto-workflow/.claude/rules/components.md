---
paths:
  - 'src/components/**'
  - 'src/pages/**'
  - 'src/hooks/**'
  - 'src/styles/**'
---

# Components and styles

- Function components and hooks. A component reads store selectors and sends actions; no game rule
  in a component, and never in a `useEffect`.
- Every visible text comes from `useTexts()` (`src/hooks/useTexts.ts`), called in the component's
  body, never written in JSX nor read once at a module's level: the player's language can change.
  A word by an engine id goes through `textOf(texts.cards, id)`; values come from
  `src/content/data/` and `src/content/shared/`. ESLint refuses `@/content/fr` here.
- Styles are plain CSS: the colour roles of `src/styles/tokens.css` (day by default, night under
  `[data-theme='night']`, as `docs/maquettes.md` says; no glow, gradient or blurred shadow), CSS
  Modules per component inside `@layer components`, container queries for layout. No CSS framework.
- The shared primitives (`Eyebrow`, `ChoiceGroup`, `StatTile`, `Glyph` in `components/shared`) sit
  in `@layer primitives`, below the components: a caller restyles one through `className`. The P4
  frames and buttons are classes of `components/shared/Frames.module.css`, taken by `composes:`:
  every button and link takes one of its sorts (primary, secondary, chipButton, choice, toggle,
  link, or pressable for a card), which carries its hover, active and disabled states; the
  exceptions are named in docs/maquettes.md ("Cadres et boutons"). Nothing read sits
  under 16 px (`--title-xs` is for surtitles, never a control); out-of-sight text composes
  `Unseen.module.css`. A pattern
  becomes a primitive at its third copy.
- CSS Modules are untyped: a class deleted from a module reads as `undefined` in its TSX without a
  type error, so grep the TSX for every class you remove. `composes:` can't be conditional: a
  style that depends on state is a second class the TSX adds. A rule moved from a component's
  module into `@layer primitives` loses to every component rule, attribute selectors included (a
  market service's `[data-covered='false']` beat the moved `:disabled`): check the composing
  components' state selectors when you move one.
- To measure a screen in a real browser (a probe, never a spec): a plain `.mjs` in the scratchpad
  that imports `chromium` from `<repo>/node_modules/playwright-core` with
  `executablePath: '/usr/bin/google-chrome'`, against `pnpm exec vite --port 5198 --strictPort`
  run in the background (5199 belongs to `pnpm screenshots`). Not through `tsx`: its build breaks
  `page.evaluate` (`__name is not defined`).
- Mobile first: works at 360 px with a thumb, touch targets at least 44 px, no required hover.
  Tap-to-place, no drag and drop. Real buttons and links, AA contrast, and motion
  that respects `prefers-reduced-motion`.
- Animations play the engine's `GameEvent`s in sequence with Motion.
- The screens follow `docs/maquettes.md` (direction P4, the "Pixel" tab of the mockup canvas): zones,
  component names, palette tokens and interaction decisions come from there. A new screen gets a
  mockup row on that canvas before its components.
