---
paths:
  - 'src/engine/**'
  - 'src/content/**'
---

# Engine and content

- `src/engine/` imports neither React, Zustand nor Motion, and never calls `Math.random`: ESLint
  enforces both. Randomness comes from the seeded rng in `rng.ts`, one forked stream per
  subsystem, so changing content never shifts another subsystem's draws.
- `apply(state, action, rng)` is the only way to change a `RunState`. It returns the next state
  (never mutates) and the `GameEvent`s, named in the past tense. The engine knows nothing of time.
- Every number lives in `src/content/data/`, every text in `src/content/fr/` (one folder per
  language, keyed by the data's ids), never typed in the engine. The engine imports
  `src/content/data/` only (ESLint, `data.spec.ts`); `src/content/shared/` holds the presentation
  values no language changes (sprites, sounds, addresses). One exception: `savedNames`, the
  frozen French names the save migration reads. Content files hold data only, no logic.
- Names come from `docs/glossaire.md`: English identifiers, one per French term. Slots and tags are
  English unions; their display names live in the content.
- Ids are branded types (`CardId`, `CustomerId`) so they can't be mixed; plain types, no classes.
- Balancing changes the data, never the code, and is logged in `docs/balance.md` (date, value
  before and after, why). The brief's numbers are the starting values.
