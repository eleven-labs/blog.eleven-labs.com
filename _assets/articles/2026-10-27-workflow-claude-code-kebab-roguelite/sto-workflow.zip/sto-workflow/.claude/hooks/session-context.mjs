// SessionStart hook: tells a new session, in a few lines, what is already going on, so it never
// relaunches a measure that runs or exists, nor works in a checkout another session uses: the
// bots running, the bot measures kept, the worktrees, and this checkout's branch and changes.
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';

const projectDir = process.env.CLAUDE_PROJECT_DIR ?? process.cwd();
const botDir = join(homedir(), '.cache', 'sto-bot');

/**
 * @param {string} bin
 * @param {string[]} args
 */
function run(bin, args) {
  try {
    return execFileSync(bin, args, {
      cwd: projectDir,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 2000, // four calls stay under the hook's 10 s
    }).trim();
  } catch {
    return '';
  }
}

const lines = [];
const bots = run('pgrep', ['-af', 'node.*scripts/bot\\.ts'])
  .split('\n')
  // One line per bot: tsx's own process, not its node child nor the workers of --jobs.
  .filter((line) => line.includes('tsx/dist/cli.mjs') && !line.includes('--slice'));
lines.push(
  bots.length
    ? `Bots running (${bots.length}): no pnpm check, vitest or screenshots until they end.\n${bots.map((b) => `  ${b.replace(/^.*scripts\/bot\.ts/, 'bot.ts')}`).join('\n')}`
    : 'No bot running.',
);
if (existsSync(botDir)) {
  const outputs = readdirSync(botDir)
    .filter((name) => name.endsWith('.txt'))
    .map((name) => ({ name, time: statSync(join(botDir, name)).mtimeMs }))
    .sort((a, b) => b.time - a.time)
    .slice(0, 5)
    .map((file) => file.name);
  if (outputs.length)
    lines.push(
      `Latest bot outputs in ${botDir}: ${outputs.join(', ')} (the bot skill publishes them).`,
    );
}
const worktrees = run('git', ['worktree', 'list']).split('\n').filter(Boolean);
if (worktrees.length > 1) lines.push(`Worktrees:\n${worktrees.map((w) => `  ${w}`).join('\n')}`);
const branch = run('git', ['branch', '--show-current']);
const changes = run('git', ['status', '--short']).split('\n').filter(Boolean).length;
lines.push(`This checkout: ${branch || 'detached'}, ${changes} changed file(s).`);

process.stdout.write(
  JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SessionStart', additionalContext: lines.join('\n') },
  }),
);
