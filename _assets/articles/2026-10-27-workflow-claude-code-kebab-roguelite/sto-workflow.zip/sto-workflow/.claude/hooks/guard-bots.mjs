// PreToolUse hook on Bash: refuses the full check, Vitest and the screenshots while a balance bot
// runs. They nearly double the bots' time, and the specs that play whole runs time out, so a red
// check would mean nothing. The PR's CI checks instead (the bot skill, /ship).
import { execFileSync } from 'node:child_process';

const input = JSON.parse(await new Response(process.stdin).text());
/** @type {string} */
const command = input.tool_input?.command ?? '';
// A heavy run starts one of the command's segments; a word in a message or a grep is no run.
const heavy =
  /^(?:cd\s+\S+\s*&&\s*)?(?:pnpm\s+(?:-C\s+\S+\s+)?(?:run\s+)?(?:check|test|test:coverage|screenshots(?::compare)?)\b|(?:pnpm\s+exec\s+|npx\s+)?vitest\b)/;
const runsHeavy = command.split(/&&|\|\||;|\|/).some((segment) => heavy.test(segment.trim()));

/** Whether a bot runs now, from any checkout or worktree: tsx's own process running bot.ts. */
function botRunning() {
  try {
    execFileSync('pgrep', ['-f', 'tsx/dist/cli\\.mjs.*scripts/bot\\.ts'], { stdio: 'ignore' });
    return true;
  } catch {
    return false; // pgrep exits 1 when nothing matches
  }
}

if (runsHeavy && botRunning()) {
  process.stdout.write(
    JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason:
          'Balance bots are running (scripts/bot.ts): no pnpm check, vitest or screenshots until ' +
          'they end. Wait for their notification, or push and let the PR’s CI check.',
      },
    }),
  );
}
