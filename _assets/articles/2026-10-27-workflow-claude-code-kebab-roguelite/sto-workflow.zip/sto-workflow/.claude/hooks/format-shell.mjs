// PreToolUse and PostToolUse hook on Bash: formats and lint-fixes the files a shell command wrote
// (sed, a script, a heredoc), as lint.mjs does for Edit and Write. Before the command it notes the
// time; after it, the project's modified and untracked files written since then go through
// Prettier and ESLint --fix. Exit 2 sends the errors left to Claude.
import { execFileSync } from 'node:child_process';
import { readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const projectDir = process.env.CLAUDE_PROJECT_DIR ?? process.cwd();
const input = JSON.parse(await new Response(process.stdin).text());
const stamp = join(tmpdir(), `claude-format-shell-${input.tool_use_id ?? 'none'}`);
const formattable = /\.(ts|tsx|js|mjs|cjs|css|json|md|ya?ml|html)$/;
const lintable = /\.(ts|tsx|js|mjs|cjs)$/;
// More files than an edit writes: a branch switched or a checkout moved by a script, whose files
// git already holds formatted.
const most = 30;

if (input.hook_event_name === 'PreToolUse') {
  writeFileSync(stamp, String(Date.now()));
  process.exit(0);
}

let since;
try {
  since = Number(readFileSync(stamp, 'utf8'));
  rmSync(stamp);
} catch {
  // no time noted before the command: nothing to compare with
  process.exit(0);
}

/** @param {string[]} args */
function git(args) {
  return execFileSync('git', args, {
    cwd: projectDir,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'ignore'],
  });
}

let files;
try {
  files = git(['ls-files', '--modified', '--others', '--exclude-standard'])
    .split('\n')
    .filter((file) => {
      if (!formattable.test(file)) return false;
      try {
        // a second's slack for file systems that round the time
        return statSync(join(projectDir, file)).mtimeMs >= since - 1000;
      } catch {
        return false; // deleted
      }
    });
} catch {
  process.exit(0); // not a git checkout
}

if (files.length === 0 || files.length > most) process.exit(0);

/**
 * @param {string} bin
 * @param {string[]} args
 */
function run(bin, args) {
  execFileSync(join(projectDir, 'node_modules', '.bin', bin), args, {
    cwd: projectDir,
    stdio: ['ignore', 2, 2],
  });
}

try {
  run('prettier', ['--write', '--log-level', 'warn', '--ignore-unknown', ...files]);
  const linted = files.filter((file) => lintable.test(file));
  if (linted.length > 0) run('eslint', ['--fix', '--no-warn-ignored', ...linted]);
} catch {
  process.exit(2);
}
