// PreToolUse hook on Bash: refuses a `git commit` whose files fail the formatting or lint check
// CI runs. The PostToolUse hook formats what Edit and Write touch, but a file changed from the
// shell (sed, a script, a heredoc) skips it; this catches it before the push instead of in CI.
// The files checked are the staged ones (and the modified ones with `-a`), in the checkout the
// commit runs in, following `cd <dir> &&` and `git -C <dir>` as guard-main.mjs does. A `git add`
// earlier on the same line hasn't run yet when this hook does: the files it will stage count too.
import { execFileSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { join, resolve } from 'node:path';

// What CI checks, on which files. Prettier skips what .prettierignore lists or doesn't know.
const checks = [
  { bin: 'prettier', args: ['--check', '--ignore-unknown', '--log-level', 'warn'], files: /./ },
  { bin: 'eslint', args: ['--no-warn-ignored'], files: /\.(ts|tsx|js|mjs|cjs)$/ },
];

const input = JSON.parse(await new Response(process.stdin).text());
const command = input.tool_input?.command ?? '';
let cwd = input.cwd ?? process.env.CLAUDE_PROJECT_DIR ?? process.cwd();

/** @param {string} reason */
function deny(reason) {
  process.stdout.write(
    JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: reason,
      },
    }),
  );
  process.exit(0);
}

/**
 * @param {string} dir
 * @param {string[]} args
 */
function git(dir, args) {
  return execFileSync('git', args, {
    cwd: dir,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'ignore'],
  }).trim();
}

/**
 * A path as the shell takes it: unquoted, `~` expanded, from the current directory.
 * @param {string} word
 */
function pathOf(word) {
  return resolve(cwd, word.replace(/^["']|["']$/g, '').replace(/^~(?=\/|$)/, homedir()));
}

/**
 * The files a `git add` will stage, from the repository's root: its paths' modified and untracked
 * files (every one without a path, or for `.`), the modified only with `-u`.
 * @param {string} dir
 * @param {string[]} args the words after `add`
 */
function toStage(dir, args) {
  const paths = args.filter((word) => !word.startsWith('-'));
  const tracked = args.some((word) => word === '-u' || word === '--update');
  try {
    return git(dir, [
      'ls-files',
      '--full-name',
      '--modified',
      ...(tracked ? [] : ['--others', '--exclude-standard']),
      '--',
      ...paths.map((path) => path.replace(/^["']|["']$/g, '')),
    ]).split('\n');
  } catch {
    // not a git checkout, or a path git doesn't know: git add will say so
    return [];
  }
}

/**
 * The failures of each check on the files of a commit, as one message, or '' when all pass.
 * @param {string} dir
 * @param {boolean} all
 * @param {string[]} added the files a `git add` earlier on the line will stage
 */
function failures(dir, all, added) {
  let root;
  try {
    root = git(dir, ['rev-parse', '--show-toplevel']);
  } catch {
    // not a git checkout: nothing to check
    return '';
  }
  const list = (/** @type {string[]} */ args) =>
    git(root, ['diff', '--name-only', '--diff-filter=ACMR', ...args]).split('\n');
  const files = [...new Set([...list(['--cached']), ...(all ? list([]) : []), ...added])].filter(
    (file) => file && existsSync(join(root, file)),
  );
  const messages = [];

  for (const { bin, args, files: pattern } of checks) {
    const path = join(root, 'node_modules', '.bin', bin);
    const matched = files.filter((file) => pattern.test(file));

    // a checkout without its dependencies can't run the check: CI still does
    if (matched.length === 0 || !existsSync(path)) continue;
    try {
      execFileSync(path, [...args, ...matched], { cwd: root, encoding: 'utf8', stdio: 'pipe' });
    } catch (error) {
      const { stdout = '', stderr = '' } = /** @type {{ stdout?: string, stderr?: string }} */ (
        error
      );
      const output = `${stdout}${stderr}`.trim();

      messages.push(`${bin} fails:\n${output.split('\n').slice(-30).join('\n')}`);
    }
  }
  return messages.join('\n\n');
}

/** The files the `git add`s met so far on the line will stage. @type {string[]} */
const added = [];

// each command of the line in turn, following its `cd`s (`cd -` is not followed)
for (const part of command.split(/&&|\|\||[;|\n]/)) {
  const cd = /^\s*cd\s+("[^"]+"|'[^']+'|\S+)\s*$/.exec(part)?.[1];

  if (cd) {
    if (cd !== '-') cwd = pathOf(cd);
    continue;
  }

  const rest = /\bgit\b(.*)/.exec(part)?.[1];

  if (rest === undefined) continue;

  // git's subcommand comes after its global options (`-C <dir>`, `-c <name>=<value>`, `--flag`)
  const words = rest.trim().split(/\s+/);
  /** @type {string | undefined} */
  let dir;
  let at = 0;

  for (; at < words.length && words[at].startsWith('-'); at++) {
    if (words[at] === '-C') dir = words[++at];
    else if (words[at] === '-c') at++;
  }

  if (words[at] === 'add') {
    added.push(...toStage(dir ? pathOf(dir) : cwd, words.slice(at + 1)));
    continue;
  }

  if (words[at] !== 'commit') continue;

  // `-a`, `--all`, or a short-flag cluster holding `a` (`-am`) commits the modified files too
  const all = words.slice(at + 1).some((word) => word === '--all' || /^-[a-zA-Z]*a/.test(word));
  const message = failures(dir ? pathOf(dir) : cwd, all, added);

  if (message) {
    deny(
      `The files of this commit fail CI's checks. Fix them (prettier --write, eslint --fix), ` +
        `stage them and commit again.\n\n${message}`,
    );
  }
}
