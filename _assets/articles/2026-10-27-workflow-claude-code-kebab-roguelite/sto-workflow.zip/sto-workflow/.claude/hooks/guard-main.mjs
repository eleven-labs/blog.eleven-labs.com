// PreToolUse hook on Bash: refuses `git commit` and `git push` on a checkout of `main`, a push
// whose target is `main`, and any force push. One branch per PR; main only moves by merged PR.
// The branch checked is the one of the checkout each git command runs in, following
// `cd <dir> &&` and `git -C <dir>`, so a commit in another worktree is judged by its own branch.
// Only this repository's checkouts are guarded.
import { execFileSync } from 'node:child_process';
import { homedir } from 'node:os';
import { resolve } from 'node:path';

const input = JSON.parse(await new Response(process.stdin).text());
const command = input.tool_input?.command ?? '';
let cwd = input.cwd ?? process.env.CLAUDE_PROJECT_DIR ?? process.cwd();

/** @param {string} reason */
function deny(reason) {
  process.stdout.write(
    JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'PreToolUse',
        permissionDecision: 'deny',
        permissionDecisionReason: reason,
      },
    }),
  );
  process.exit(0);
}

/**
 * @param {string} dir
 * @param {string[]} args
 */
function git(dir, args) {
  try {
    return execFileSync('git', args, {
      cwd: dir,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    }).trim();
  } catch {
    // not a git checkout: nothing to guard
    return '';
  }
}

// The game's repository, shared by its worktrees: another repository (~/.claude, which commits
// on its main) follows its own rules.
const project = git(process.env.CLAUDE_PROJECT_DIR ?? cwd, [
  'rev-parse',
  '--path-format=absolute',
  '--git-common-dir',
]);

/** @param {string} dir */
function inProject(dir) {
  const common = git(dir, ['rev-parse', '--path-format=absolute', '--git-common-dir']);
  return common !== '' && common === project;
}

/**
 * A path as the shell takes it: unquoted, `~` expanded, from the current directory.
 * @param {string} word
 */
function pathOf(word) {
  return resolve(cwd, word.replace(/^["']|["']$/g, '').replace(/^~(?=\/|$)/, homedir()));
}

// each command of the line in turn, following its `cd`s (`cd -` is not followed)
for (const part of command.split(/&&|\|\||[;|\n]/)) {
  const cd = /^\s*cd\s+("[^"]+"|'[^']+'|\S+)\s*$/.exec(part)?.[1];

  if (cd) {
    if (cd !== '-') cwd = pathOf(cd);
    continue;
  }

  const rest = /\bgit\b(.*)/.exec(part)?.[1];

  if (rest === undefined) continue;

  // git's subcommand comes after its global options (`-C <dir>`, `-c <name>=<value>`, `--flag`)
  const words = rest.trim().split(/\s+/);
  /** @type {string | undefined} */
  let dir;
  let at = 0;

  for (; at < words.length && words[at].startsWith('-'); at++) {
    if (words[at] === '-C') dir = words[++at];
    else if (words[at] === '-c') at++;
  }

  const verb = words[at];

  if (verb !== 'commit' && verb !== 'push') continue;

  const checkout = dir ? pathOf(dir) : cwd;

  if (!inProject(checkout)) continue;
  if (verb === 'push' && /(--force\b|--force-with-lease\b|\s-f\b|\s\+\S)/.test(rest)) {
    deny('Force pushes are not used in this repo: rebase locally, then push a new branch or PR.');
  }
  if (verb === 'push' && /(\s|:|refs\/heads\/)main(\s|$)/.test(rest)) {
    deny('This push targets main: main only moves by merged PR.');
  }

  if (git(checkout, ['rev-parse', '--abbrev-ref', 'HEAD']) === 'main') {
    deny(
      'The checkout is on main. Create the branch first (git switch -c milestone-N/<slug>) ' +
        'and commit there; main only moves by merged PR.',
    );
  }
}
