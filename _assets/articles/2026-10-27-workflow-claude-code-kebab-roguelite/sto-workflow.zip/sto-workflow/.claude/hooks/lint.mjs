// PostToolUse hook: format and lint-fix the file Claude just edited or wrote, with the same tools
// as `pnpm lint:check`. Exit 2 sends the errors left to Claude.
import { execFileSync } from 'node:child_process';
import { join, relative } from 'node:path';

const projectDir = process.env.CLAUDE_PROJECT_DIR ?? process.cwd();
const input = JSON.parse(await new Response(process.stdin).text());
const path = input.tool_input?.file_path;
const file = path && relative(projectDir, path);
const skipped = /^(node_modules|dist|coverage|\.\.)\//;
const formattable = /\.(ts|tsx|js|mjs|cjs|css|json|md|ya?ml|html)$/;
const lintable = /\.(ts|tsx|js|mjs|cjs)$/;

/**
 * @param {string} bin
 * @param {string[]} args
 */
function run(bin, args) {
  execFileSync(join(projectDir, 'node_modules', '.bin', bin), args, {
    cwd: projectDir,
    stdio: ['ignore', 2, 2],
  });
}

if (file && !skipped.test(file) && formattable.test(file)) {
  try {
    run('prettier', ['--write', '--log-level', 'warn', file]);
    if (lintable.test(file)) run('eslint', ['--fix', file]);
  } catch {
    process.exit(2);
  }
}
