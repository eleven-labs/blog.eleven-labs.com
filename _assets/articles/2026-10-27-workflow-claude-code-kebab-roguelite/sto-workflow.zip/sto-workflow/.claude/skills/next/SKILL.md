---
name: next
description: Start the next PR of Salade Tomate Oignon without naming it - take the milestone and the boxes from the last merged PR's next-session prompt, then follow the /milestone procedure (land the PR, ground, branch, plan, test-first). Use when the user says "next", "/next", "next PR", or "start the next one".
argument-hint: '[N] [the boxes of the PR]'
---

# Start the next PR

A shortcut for `/milestone`: same procedure, but the session finds what to start by itself.

1. **What to start.** With `$ARGUMENTS`, they name the milestone (and maybe the boxes). Without
   them, read the last merged PR (`gh pr list --state merged --limit 1`, then
   `gh pr view <number> --json body -q .body`): its "Prompt de la prochaine session" names the
   milestone N, the PR's boxes and the decisions to honour. If the current branch's PR isn't merged
   yet, use its own body instead; `/milestone` stops on it unless the user asked to stack. If the
   prompt says `/milestone N+1`, the next milestone starts.
2. **Then follow `.claude/skills/milestone/SKILL.md` to the letter**, with that N and that prompt
   as its arguments: land the previous PR, ground yourself, prepare the branch, plan (in plan
   mode when decisions are open) and show the first red test. Say in one line which milestone and PR you took, and from where.
