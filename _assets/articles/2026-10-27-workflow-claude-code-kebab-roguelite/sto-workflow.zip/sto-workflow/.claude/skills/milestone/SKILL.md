---
name: milestone
description: Start milestone N of Salade Tomate Oignon, or its next PR, from a clean context - land the previous PR if it merged, read issue #N and the documents of record, branch milestone-N/<slug>, walk through the plan (in plan mode when decisions are open), then work test-first. Use when the user says "start milestone N", "/milestone N", or a next-session prompt names it ("next PR" without N is the next skill).
argument-hint: <N>
---

# Start milestone $ARGUMENTS (or its next PR)

The milestone number is `$ARGUMENTS` (1 to 8, one GitHub issue each, #1 to #8). A milestone is
delivered in one PR per item or small group of boxes (engine, then store, then UI), so this skill
starts either the milestone's first PR or its next one. Everything the session needs is in the
repo or the issue: don't ask the user for context that is written down.

## 1. Land the previous PR

1. `git status --short` and `git branch --show-current`. Uncommitted work is not yours to drop:
   stop and ask.
2. If the current branch's PR is merged (`gh pr view --json state,number`): switch to `main`,
   `git pull --ff-only`, and delete the branch with `git branch -d`. Its boxes were ticked by
   `/ship`; check them on the issue.
3. If it isn't merged yet, say so and stop, unless the user asked to stack on it.
4. For a new milestone, the previous one must be done: issue N-1 closed or every box ticked. If
   it isn't, stop and say so.

## 2. Ground yourself (read, don't write)

1. `CLAUDE.md` is loaded. Read `docs/glossaire.md`, the current milestone's section of
   `CHANGELOG.md` (its first 30 lines are enough: the last PR's body says the rest) and the
   `README.md` of each `src/` folder you will touch.
2. `gh issue view N`: the unticked boxes are the scope left, the "Done when" line the acceptance
   test of the whole milestone. When the next-session prompt names another issue (a plan of its
   own, such as #49's pixel art restyle), read it too: its ordered PR list is this PR's scope,
   and the first unticked line is the one to start.
3. Read the body of the last merged PR (`gh pr list --state merged --limit 1`, then
   `gh pr view <number> --json body -q .body`): its "Décisions" section and its next-session
   prompt carry decisions the issue doesn't record.
4. Read the brief sections the PR depends on in `docs/brief.md` (grep for the heading, read
   those sections only). Run the cheap check of the `brief` skill if the snapshot is older than a
   week.
5. For a PR that changes a screen: read the zone of that screen in `docs/maquettes.md`, not the
   whole file. Open the canvas itself (Artifact tool, action `read`, url in that file) only for
   exact sizes or colors.
6. Read the engine and content files the plan touches, as they are, not as the brief planned
   them: find them by grepping the glossary's identifiers, or ask an `Explore` agent for the map
   when the scope is wide. Don't read `src/engine` or `src/content/fr` whole.

## 3. Prepare the branch

```sh
git switch main && git pull --ff-only
pnpm install --frozen-lockfile
gh run list --branch main --limit 1
git switch -c milestone-N/<short-english-slug>
```

The CI run on main is the check of record: don't re-run `pnpm check` on main locally. A red CI on
main is reported, not fixed in passing.

## 4. Plan, walk through it, then show the first red test

Pick this PR's boxes: the next unticked ones that review well together, engine before stores
before components. Turn them into an ordered list of steps. For each step name the spec file that
comes first (`src/tests/...`), the engine or content change, then the component. Rules of the
brief get a test named after them; value tables become `it.each`.

Enter plan mode when this PR has decisions still open. Skip it when the brief, the issue and the
merged PRs already settle every one: walk through the steps in the chat and start. Either way,
walk through which boxes this PR covers and which it leaves for the next, and the steps. In plan
mode, add the open decisions with their options (recommended one first), keep the ones the brief
or a merged PR already settled, and walk through before asking for approval.

Once the plan is walked through (and approved, in plan mode), start step 1 by writing its spec
and running it red (the project rule: show the failing run before the code). Use
`pnpm exec vitest run --silent=false <file>` for one file, and
`pnpm exec vitest related --run <changed files>` at the end of a step. `pnpm check` runs once, in
`/ship`.

## 5. While working

- Every visible text in `src/content/fr/`, every number too. Names from the glossary, or grow it
  first.
- The PostToolUse hook formats and lint-fixes each file you edit; a PreToolUse hook refuses
  commits on `main`, pushes to it and force pushes.
- Commit when a step's specs are green (the commit hook checks Prettier and ESLint), with a
  short imperative English title and a body that says why.
- When this PR's boxes are done, run `/ship`.
