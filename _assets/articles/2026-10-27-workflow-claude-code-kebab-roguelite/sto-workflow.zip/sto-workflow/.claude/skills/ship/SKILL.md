---
name: ship
description: Finish the current branch of Salade Tomate Oignon (one PR of a milestone) - review the diff, run pnpm check once, update CHANGELOG.md, tick the issue's boxes, push and open the PR with the next session's prompt. Use when the user says "ship", "open the PR", "finish the milestone", "finish the PR", or "/ship".
---

# Ship the current branch

Work on the current `milestone-N/...` (or `chore/...`) branch. Never on `main`, never merge: the
user merges. Merging deploys: `main` goes live on https://<game-site> by itself.

## 1. Review

`git status --short`: uncommitted work is committed in sensible steps first. Then run
`/code-review medium` on the branch, `/code-review high` when it changes `src/engine/`. Fix what
is real, say what you left and why.

## 2. Green

`pnpm check`, once, after the review's fixes: it's the only full check of the PR (during the work,
targeted vitest runs and the commit hook do). A red check is fixed, or reported with its output
and the ship stops there. While bots run, a hook refuses it: push without it (step 5) and wait
for the PR's CI in the background (`gh pr checks --watch`, `run_in_background`); a red CI is fixed
the same way.

Then `pnpm e2e` (about 2 min), when the PR touches `src/`, `e2e/` or `scripts/screens.ts`: the
built site in Chrome, every screen checked for text out of its box in the three languages, and
the smoke test. The CI doesn't run it yet.

## 3. Proof

- **Screens** (whenever the PR changes what a page shows): once `/code-review` is done and
  everything is committed, `pnpm screenshots:compare m<N>-<slug>` (`--only <prefix>` for some
  screens). It shoots `origin/main` then the branch in this checkout, at 360 px and on desktop in
  both themes; when `origin/main`'s tree was already shot (the merged branch's last run, kept in
  `~/.cache` by tree), that set is the before and only the branch is shot. It keeps the shots that
  differ, pushes them to the orphan `pr-screenshots` branch
  (`m<N>-<slug>/before/` and `/after/`) and prints the before/after table, raw blob URLs since the
  repo is private: paste it, or the rows that tell, under **Vérification**. Don't edit files while
  it runs: the dev server reloads and a shot fails.
- **Values**: when a number in `src/content/data/` changed, say in **Vérification** what
  `pnpm play` (same seed before and after) showed, beside the `docs/balance.md` line.

## 4. Record

1. `CHANGELOG.md`: a `## Jalon N : <titre français>` section (or `## Outillage` for a chore) with
   short French bullets of what the player or the developer gets. Newest section first; a later
   PR of the same milestone adds its bullets to the milestone's section.
2. `docs/balance.md` if a value changed for balance reasons. `docs/glossaire.md` if a term was
   added.
3. Tick the issue's boxes: `gh issue view N --json body -q .body`, replace `- [ ]` with `- [x]`
   for what the PR delivers, `gh issue edit N --body-file <tmp>`. Leave undelivered boxes open and
   say so in the PR. A PR taken from another issue's plan (such as #49) ticks its line there, and
   its next-session prompt names that issue and its next line, so `/next` finds it.

## 5. Open the PR

```sh
git push -u origin HEAD
gh pr create --title "Milestone N: <what this PR delivers>" --body-file <tmp>
```

PR body, in this order:

1. **Résumé**: three to six bullets, French, what the PR delivers against issue #N (`Closes #N`
   only if every box is ticked).
2. **Vérification**: the commands run and their result (`pnpm check` or the PR's CI green, coverage figure,
   anything manual such as "service joué au pouce à 360 px", `pnpm play` for changed values).
   The before/after screenshots table goes under it when step 3 took them.
3. **Décisions**: choices made that the issue and the brief don't record (defaults picked,
   deviations from the mockups, deferred boxes). This is what the next session reads.
4. **Prompt de la prochaine session**: one fenced `text` block of plain prose, no markdown or
   backticks inside, that copies in one go. Since `/milestone` carries the procedure and the
   repo carries the context, keep it short: `Run /milestone N for Salade Tomate Oignon (repo
<owner>/salade-tomate-oignon), next PR: <the boxes it takes>.` (or `/milestone N+1` once every
   box of N is ticked), then only the pointers the next PR needs beyond the issue (a canvas row,
   a doc section, a flag, an artifact). Don't repeat the Décisions: `/milestone` reads them from
   this PR's body.
5. The attribution line the harness asks for.

Print the PR URL and stop. Don't merge, don't delete the branch: `/milestone` lands it once
merged.

The guard hook reads the whole command line, heredocs included: write a PR body or a commit
message that quotes git commands to a file with the Write tool, and pass the file.
