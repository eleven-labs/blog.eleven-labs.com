// Builds the "Mesures du bot fort" page from a data folder: manifest.json (one entry per
// variant) and the raw output of each run beside it, as `<variant>-<chef>.txt`.
//
// node .claude/skills/bot/build.mjs <data folder>   ->   <data folder>/mesures-bot.html

import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const dir = process.argv[2];
if (!dir) throw new Error('Usage: node build.mjs <data folder>');

const chefs = { classic: 'Classique', veggie: 'Végé' };
const head = /^(\d+) runs, .*: (\d+) gagnées/;
// `perdue (quartier 3, réputation, boss)`, or `perdue (quartier 2, loyer)` with no node.
const loss = /^\s+perdue \(quartier (\d), ([^,)]+)(?:, (\w+))?\)\s+(\d+)/;
const district = /^quartier (\d) : réputation à l’entrée du boss ([\d.]+)/;

const escape = (text) =>
  String(text)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
// One decimal, halves rounded up (91.25 reads 91.3, as the bot prints it).
const fixed = (value) => (Math.round(value * 10 + 1e-9) / 10).toFixed(1);

// The bot's report: the runs won, then one line per kind of loss, then one line per district.
function parse(path) {
  const lines = readFileSync(path, 'utf8').split('\n');
  const top = head.exec(lines[0] ?? '');
  if (!top) return undefined;
  const runs = Number(top[1]);
  let losses = 0; // the runs lost, from the loss lines: unfinished runs are not losses
  const byDistrict = { 1: 0, 2: 0, 3: 0 };
  const boss = { 1: 0, 2: 0, 3: 0 };
  const reputation = {};
  let rent = 0;
  for (const line of lines) {
    const lost = loss.exec(line);
    if (lost) {
      const [, d, cause, kind, n] = lost;
      losses += Number(n);
      byDistrict[d] += Number(n);
      if (kind === 'boss') boss[d] += Number(n);
      if (cause.startsWith('loyer')) rent += Number(n);
    }
    const entry = district.exec(line);
    if (entry) reputation[entry[1]] = Number(entry[2]);
  }
  const share = (n) => (losses ? (100 * n) / losses : 0);
  return {
    runs,
    win: (100 * Number(top[2])) / runs,
    q: [1, 2, 3].map((d) => share(byDistrict[d])),
    boss: [1, 2, 3].map((d) => share(boss[d])),
    rent: share(rent),
    reputation: [1, 2, 3].map((d) => (reputation[d] ?? 0).toFixed(1)),
    raw: lines.filter((line) => !line.includes('node_modules/.bin/tsx')).join('\n'),
  };
}

// A value against its target: inside, within 5 points, or off.
function chip(value, low, high) {
  const tone =
    value >= low && value <= high ? 'ok' : value >= low - 5 && value <= high + 5 ? 'near' : 'off';
  return `<span class="v ${tone}">${fixed(value)}%</span>`;
}

function row(variant, chef, result) {
  const name = escape(chefs[chef] ?? chef);
  const id = escape(variant.id);
  if (!result)
    return `<tr class="pending"><th scope="row">${id}</th><td>${name}</td><td colspan="8">en cours…</td></tr>`;
  const [q1, q2, q3] = result.q;
  return [
    `<tr><th scope="row">${id}</th><td>${name}</td>`,
    `<td class="n">${result.runs}</td>`,
    `<td>${chip(result.win, 55, 65)}</td>`,
    `<td>${chip(q1, 0, 15)}</td><td>${chip(q2, 25, 35)}</td><td>${chip(q3, 50, 60)}</td>`,
    `<td>${result.boss.map((b) => chip(b, 0, 20)).join(' ')}</td>`,
    `<td><span class="v later">${fixed(result.rent)}%</span></td>`,
    `<td class="n">${result.reputation.join(' · ')}</td></tr>`,
  ].join('');
}

const variants = JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8'));
const rows = [];
const details = [];
for (const variant of variants) {
  for (const chef of variant.chefs) {
    const path = join(dir, `${variant.id}-${chef}.txt`);
    const result = existsSync(path) ? parse(path) : undefined;
    rows.push(row(variant, chef, result));
    if (result)
      details.push(
        `<details id="${escape(`${variant.id}-${chef}`)}"><summary><b>${escape(variant.id)}</b> · ${escape(chefs[chef] ?? chef)} · ` +
          `${result.runs} graines · ${fixed(result.win)} % gagnées</summary><pre>${escape(result.raw)}</pre></details>`,
      );
  }
}
const changes = variants
  .map(
    (v) =>
      `<li><b>${escape(v.id)}</b> <span class="meta">${escape(v.date)} · ${escape(v.branch)}</span><p>${escape(v.changes)}</p></li>`,
  )
  .join('');

const page = readFileSync(join(here, 'template.html'), 'utf8')
  // Functions, so that a `$` in the data is never read as a replacement pattern.
  .replace('{{ROWS}}', () => rows.join('\n'))
  .replace('{{CHANGES}}', () => changes)
  .replace('{{DETAILS}}', () => details.join('\n'));
writeFileSync(join(dir, 'mesures-bot.html'), page);
