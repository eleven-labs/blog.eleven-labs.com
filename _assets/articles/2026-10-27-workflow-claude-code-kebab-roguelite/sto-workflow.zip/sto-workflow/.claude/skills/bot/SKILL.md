---
name: bot
description: Run the balance bots of Salade Tomate Oignon (pnpm bot, the strong bot of scripts/smart.ts) and keep every measure in the artifact "Mesures du bot fort". Use before launching any bot run, balance variant or baseline, when the user says "bot", "mesure", "lance le bot" or "/bot", and before re-running a baseline (it may already be measured).
---

# Measure with the bots

The strong bot (`pnpm bot --run --smart`) is the balance yardstick: it stands in for the
experienced player of the brief's targets (decided 24 October 2026). A run is slow, about 30 min
for 1000 seeds of one chef on 6 cores, so every measure is kept, and none is run twice.

## 1. Before running: is it already measured?

Every measure since step 9 of #75 is in the artifact **"Mesures du bot fort"**,
<private-artifact>. Read it first (Artifact tool, action `read`).
A baseline of main is measured once per merged PR: take it from there, or from the last line of
`docs/balance.md`, never re-run it.

The data folder is `~/.cache/sto-bot/`, outside any session and any checkout: `manifest.json`
and one raw output per run, `<variant>-<chef>.txt`. It is also published with the artifact. On a
machine where the folder is missing or behind the artifact, fetch the artifact's files into it
(action `read` with `paths`) before adding a run, so that the next publish keeps them all. The
SessionStart hook lists the bots running and the latest outputs.

## 2. Running

- Launch without asking, always `--jobs 6` (half the machine), the chefs one after the other,
  never in parallel. Say in one line what runs and how long it takes.
- Run in the background (`run_in_background`), never in the foreground, and don't poll: the
  notification comes when it ends.
- While bots run, run neither vitest nor screenshots: they nearly double the bots' time, and specs
  that play whole runs time out (a red `pnpm check` then means nothing).
- **1000 seeds at most, never more** (decided by Giuseppe on 26 October 2026: measures must be
  quick). Explore at `--seeds 500` (about 15 min per chef); the final measure that goes into
  `docs/balance.md` is 1000 seeds (about 30 min per chef). Before that date some finals ran at
  2000: they stay as they are, nobody reruns them.
- A variant runs from a throwaway git worktree, with the repo's tsx and no
  install: `git worktree add --detach ~/.cache/sto-bot/wt-X main`, edit its `src/content/data/`, then
  `cd ~/.cache/sto-bot/wt-X && <repo>/node_modules/.bin/tsx --tsconfig tsconfig.scripts.json
scripts/bot.ts --run --smart --chef <id> --seeds 500 --jobs 6 > ~/.cache/sto-bot/X-<id>.txt`. A symlinked
  `node_modules` makes `pnpm bot` fail. Remove the worktrees (`git worktree remove`) once the PR's values are chosen.
- To queue runs, chain them in one background command (`run A; run B`). Never wait for a
  running bot with `while pgrep -f "<its arguments>"`: the waiting shell's own command line holds
  the same text, so the loop never ends (it held F and G 40 minutes on 24 October 2026). To
  queue behind a run already started, bracket a letter: `pgrep -f "[c]hef veggie --seeds 500"`.
- The shell is zsh: `set -- $var` doesn't split words, `==` in `echo` is an error. Loop over
  explicit words (`for c in classic veggie; do …; done`).

## 3. After each run: publish

1. Add the variant to `~/.cache/sto-bot/manifest.json` (its entry lists before running, so the
   page shows it "en cours"):
   `{"id": "E", "date": "2026-10-24", "branch": "milestone-8/tuning", "changes": "What changed, against main, with the values", "chefs": ["classic", "veggie"]}`.
2. `node .claude/skills/bot/build.mjs ~/.cache/sto-bot` writes `~/.cache/sto-bot/mesures-bot.html`.
3. The Artifact tool reads only the working directory and the scratchpad: copy the folder's
   files (not the worktrees) into `<scratchpad>/bots/`. Publish the page from there to the same
   URL (`url` above), with `manifest.json` and the new `.txt` outputs in `files` (published at
   their own names, `root` that copy, `contentType` `text/plain` for the outputs); the files
   already published stay.
4. Give the user the run's numbers against the targets in a few lines, and what you try next.

## 4. In the PR

The final measure (1000 seeds, each chef) goes into a line of `docs/balance.md`: win rate,
losses by district, at each boss and at the rent, recipe share. Explored variants are cited by
their id in the artifact, not copied.

A PR that changes a value regenerates the daily seed list too, once its values are chosen:
`pnpm daily-seeds` (in the background, `--jobs 6`, about an hour for 730 days, like a measure: no vitest meanwhile) rewrites
`src/content/data/dailySeeds.ts`, one seed a day the strong bot wins with the default chef.
