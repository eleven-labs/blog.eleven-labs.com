---
name: brief
description: Refresh docs/brief.md, the generated snapshot of the game brief, from its live Claude Docs doc, or check whether the doc changed. Use when the user says the brief changed, when starting a milestone, or when docs/brief.md looks stale. Never web-fetch the doc.
---

# Refresh the brief snapshot

`docs/brief.md` is generated from the doc "Kebab Roguelite — Brief de jeu"
(<private-artifact>). Sessions read the snapshot;
only this skill talks to the doc. Never edit `docs/brief.md` by hand.

## 1. Cheap check: did the doc change?

Load the Claude Docs tools if they are deferred (`ToolSearch` with
`select:mcp__claude_ai_Claude_Docs__read`). Then:

1. `read` with `ref: {"object":"project","id":"<doc-id>"}`. The
   result lists one tab; note its `content.id` (the prose node, `<node-id>` at the time of
   writing, but take the value returned).
2. `read` that node with `engine: "prose"`, `container: {"kind":"project","id":"<doc id>"}` and
   `payload: {"projection":"outline"}`. The outline is small and carries `rev`.
3. Compare `rev` with the revision in the first line of `docs/brief.md`. Same number: stop and say
   the snapshot is current.

## 2. Regenerate

1. `read` the same node with `engine: "prose"` and the `container`, and **no `payload`** (the full
   read). It is about 100 kB, so Claude Code saves it to a file and prints its path
   (`.../tool-results/mcp-claude_ai_Claude_Docs-read-<id>.txt`). If it ever comes back inline,
   write the JSON to a file in the scratchpad directory instead.
2. Run, from the project root:

   ```sh
   node scripts/brief-to-md.mjs <that file> > docs/brief.md
   ```

3. `git diff --stat docs/brief.md` and `git diff docs/brief.md`: tell the user what changed in
   plain words. A change under "Règles détaillées" or in a content table means a value in
   `src/content/data/` or a rule test may need to follow: name the files, don't change them unless
   asked, and remind that balancing changes go in `docs/balance.md`.

## Notes

- `docs/brief.md` is in `.prettierignore`: the converter owns its formatting.
- The converter handles headings, lists, tables, bold, inline code, code blocks (CDATA), the date
  and mention chips, and replaces embedded diagrams with "[schéma dans le doc]". A new block type
  that it drops shows up as missing text in the diff: extend `scripts/brief-to-md.mjs` then.
