# CLAUDE.md

**Salade Tomate Oignon**: a solo deckbuilder roguelite in the browser, where you run a kebab shop.
React 19 + strict TypeScript on Vite 8, Zustand, React Router, Motion. pnpm, Node 24
(`.nvmrc`). The game speaks French; the code speaks English.

Topic rules live in `.claude/rules/` and load when you touch matching files (engine and content,
components and styles, stores, tests, CI). Don't inventory the code here or there: write only what
the code can't tell.

## Documents of record

- **The brief** "Kebab Roguelite — Brief de jeu" is the design of record. Read `docs/brief.md`, a
  generated snapshot: grep it, never web-fetch anything. Its "Règles détaillées" are followed to
  the letter; its numbers are starting values that live in `src/content/data/`. The live doc is
  <private-artifact>; `/brief` checks it and
  regenerates the snapshot through the Claude Docs connector.
- **The UI design** is the pixel art direction P4 of the Design canvas "Maquettes du service"
  (<private-artifact>). `docs/maquettes.md` describes it zone by
  zone with the component mapping, palette and interaction decisions: read the zone you need
  there, open the canvas (Artifact tool, action `read`) only for exact pixels. The logo is "L'enseigne STO" (H2) on the
  canvas "Noms et logos du kebab roguelite" (<private-artifact>);
  its 16 × 16 icon is `public/favicon.svg`, and `pnpm icons` draws the app's icons from it.
- **Words:** `docs/glossaire.md` maps each French term to its one English identifier. An engine
  function whose name isn't in it gets renamed, or the glossary grows first.
- **Balance:** `docs/balance.md` logs every value change (date, before, after, why).

## Direction

- **Core loop:** a run is 3 districts of 8 nodes. A service node queues 3 to 5 customers; for each
  one you build a kebab from a hand of 6 ingredient cards (bread required, then meat, toppings,
  sauces, an extra) and serve it against the customer's contract: a threshold, firm demands,
  preferred tags, patience. Rent is due at the end of each district. Reputation at 0 or unpaid
  rent ends the run.
- **Three choices that make it this game:** the spit is the run's health (each meat card eats a
  slice); a customer is a readable contract, never hidden information; rent is the economic boss.
- **Shape of the code:** the engine is a pure, seeded reducer (`apply(state, action, rng)` returns
  the next `RunState` and the `GameEvent`s the UI plays in sequence); stores hold state and call
  it; components read selectors. Content is data: values in `src/content/data/`, words in
  `src/content/fr/` (a new card is an entry in each plus an image, no code). Details in the rules.
- **Constraints:** mobile first at 360 px, playable with a thumb, no required hover; two columns
  on desktop. Initial bundle under 250 kB gzipped, no network requests in play. Full keyboard on
  desktop, AA contrast, `prefers-reduced-motion`. No CSS framework, no state library but Zustand,
  no external API or account. Art is named placeholder SVGs that Giuseppe replaces; never generate
  art.

## Milestones

One GitHub issue each (#1 to #8). Milestones 1 to 7 are done; 8, polish (#8), is under way, with
the balance plan of #75 and the issues that hang off it. **Every push to `main` deploys** to
the game's private site (behind a Google login).

## Commands

```sh
pnpm dev                     # Vite dev server
pnpm check                   # lint + format check, type-check, coverage, then build: what CI runs
pnpm lint                    # ESLint --fix, then Prettier --write
pnpm test                    # Vitest in watch mode
pnpm exec vitest run src/tests/engine/scoring.spec.ts   # single file
pnpm exec vitest run -t "test name pattern"             # single test
pnpm e2e                                                # Playwright: text overflow in every language, smoke test
pnpm screenshots                                        # every screen, 360 px and desktop, both themes
pnpm screenshots:compare m8-slug                        # before/after of the branch, for its PR
pnpm playtest exports/*.json [--replay]                 # playtesters' files vs the brief's targets
```

Skills in `.claude/skills/` carry the procedures: `/milestone N` lands the merged PR and starts
the milestone's next PR (plan mode first), `/next` does the same with N and the boxes taken from
the last merged PR's next-session prompt, `/ship` finishes the branch into a PR, `/brief`
refreshes `docs/brief.md`, `/bot` runs the balance bots and keeps their measures. Change the
procedure there, not here.

## Workflow

- **TDD:** write the spec, run it and show it fail, then write the code. The engine always, and
  every numbered rule of the brief has a test named after it; the brief's example (Karim, score 15)
  stays the reference regression test. Components get behaviour tests, never CSS or animation.
- `pnpm check` runs once per PR, in `/ship`; during the work, targeted vitest runs and the commit
  hook. The CI is the check of record for `main`. The 90 % coverage gate applies to
  `src/engine/` only.
- Style is Prettier (width 100, single quotes) plus ESLint. Hooks in `.claude/hooks/` format and
  lint-fix every file Claude edits or a shell command writes (up to 30 at once: more is a branch
  switch), refuse commits on `main`, pushes to it and force pushes, and refuse a commit whose
  files fail Prettier or ESLint, a `git add` on the same line counted.
- A milestone is delivered in several small PRs, one per item or small group of boxes (engine,
  then store, then UI), each on its own branch (`milestone-N/name`): they review better than one
  PR per milestone. Each PR is reviewed with `/code-review` before it's opened, ticks the boxes it
  delivers, updates `CHANGELOG.md`, and ends with the next session's prompt (`/ship` has the
  template).
- **One session per checkout.** A second session in parallel works in its own worktree
  (`git worktree add ../sto-<slug> -b milestone-N/<slug> main`, then `pnpm install` there):
  a branch switch or `pnpm screenshots:compare` in a shared checkout moves the other session's
  files.
- **Playtest feedback:** gameplay remarks become boxes in a playtest issue, balance remarks go to
  #75.
