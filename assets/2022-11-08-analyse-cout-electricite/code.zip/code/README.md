# calcul-cout-electricite

Calcul du coût de l'électricité en fonction du tarif choisi.

## Installation

```shell
pip install virtualenv
virtualenv venv
pip install -r requirements.txt
. venv/bin/activate
```

## Ouvrir et lancer les notebooks

```shell
jupyter notebook
```

Ou avec Visual Studio Code, le rendu est immédiat.
